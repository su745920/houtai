<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use App\Utils\RPC;
use App\Models\{Currency,
    Address,
    AccountLog,
    Setting,
    Users,
    UsersWallet,
    UsersWalletOut,
    LeverTransaction,
    CurrencyQuotation
};
use App\Events\WithdrawSubmitEvent;
use App;
use Illuminate\Support\Facades\Redis;
use Symfony\Component\Console\Input\Input;

class Wallet2024Controller extends Controller
{
    
    public function getWebSiteConfig()
    {


        $title=Setting::getValueByKey("web_site_title");
        $desc=Setting::getValueByKey("web_site_desc");
        $keyword=Setting::getValueByKey("web_site_keyword");

        $jo["title"]=$title;
        $jo["desc"]=$title;
        $jo["keyword"]=$keyword;


        return $this->success($jo);

    }
    
    
    public function setOnline()
    {
        try {
            $user_id = Users::getUserId();
            $userStr="#".$user_id.'#';
            $onlineUserStr = Redis::get($userStr);
            if(empty($onlineUserStr)) {
               Redis::set($userStr, 'online');
            }
            return $this->success("刷新成功".$userStr);
        }catch (\Exception $ex){

        }
        return $this->success("刷新失败");
    }
    
    public function setOffline()
    {
        try {
            $user_id = Users::getUserId();
            $userStr="#".$user_id.'#';
            Redis::del($userStr);
        }catch (\Exception $ex){

        }
        return $this->success("刷新成功");
    }
    
    //  http://192.168.16.108/walletList2024

    public function getUsdtPriceV3($usdtPriceList,$coin){
            foreach ($usdtPriceList as $tmpCoin){
                $currencyName=$tmpCoin['currencyName'];
                if ($coin==$currencyName){
                    return  $tmpCoin['close'];
                }
            }
    }

    public function walletList(Request $request)
    {
        $lang = request()->input('lang', 'en');

        $user_id = Users::getUserId();

        if (empty($user_id)) {
            return $this->error(trans('wallet.cscw'));
        }

        $usdtPriceList=Currency::getAllUsdtPriceV2();


        $sql="select legal_balance,change_balance,earn_balance,micro_balance,currency,lever_balance from users_wallet  where user_id=".$user_id;
        $sql=$sql." and (legal_balance>0 or change_balance>0 or lever_balance>0 or earn_balance>0 or micro_balance>0 )";
        $walletList = DB::select($sql);
        $earn_balance=0;
        $legal_balance=0;
        $change_balance=0;
        $lever_balance=0;
        $micro_balance=0;
        
        foreach ($walletList as $walletPO){
            $currencyId=$walletPO->currency;
            $currencyName=Currency::getNameById($currencyId);

            if ($currencyName=="CNY"){
                $legal_balanceTmp = $walletPO->legal_balance;
                if (!empty($legal_balanceTmp)&&$legal_balanceTmp>0){
                    $rmb = Setting::getValueByKey('rmb');
                    $legal_balance=$legal_balance+bc_div($legal_balanceTmp,$rmb);
                }

            }elseif ($currencyName=="VND"){
                $legal_balanceTmp = $walletPO->legal_balance;
                if (!empty($legal_balanceTmp)&&$legal_balanceTmp>0){
                    $vnd = Setting::getValueByKey('vnd');
                    $legal_balance=$legal_balance+bc_div($legal_balanceTmp,$vnd);
                }

            }elseif ($currencyName=="IDR"){
                $legal_balanceTmp = $walletPO->legal_balance;
                if (!empty($legal_balanceTmp)&&$legal_balanceTmp>0){
                    $idr = Setting::getValueByKey('idr');
                    $legal_balance=$legal_balance+bc_div($legal_balanceTmp,$idr);
                }
            }elseif ($currencyName=="THB"){
                $legal_balanceTmp = $walletPO->legal_balance;
                if (!empty($legal_balanceTmp)&&$legal_balanceTmp>0){
                    $thb = Setting::getValueByKey('thb');
                    $legal_balance=$legal_balance+bc_div($legal_balanceTmp,$thb);
                }
            }elseif ($currencyName=="USD"){
                $legal_balanceTmp = $walletPO->legal_balance;
                if (!empty($legal_balanceTmp)&&$legal_balanceTmp>0){
                    $usd = Setting::getValueByKey('usd');
                    $legal_balance=$legal_balance+bc_div($legal_balanceTmp,$usd);
                }
            }elseif ($currencyName=="EUR"){
                $legal_balanceTmp = $walletPO->legal_balance;
                if (!empty($legal_balanceTmp)&&$legal_balanceTmp>0){
                    $eur = Setting::getValueByKey('eur');
                    $legal_balance=$legal_balance+bc_div($legal_balanceTmp,$eur);
                }
            }elseif ($currencyName=="GBP"){
                $legal_balanceTmp = $walletPO->legal_balance;
                if (!empty($legal_balanceTmp)&&$legal_balanceTmp>0){
                    $gbp = Setting::getValueByKey('gbp');
                    $legal_balance=$legal_balance+bc_div($legal_balanceTmp,$gbp);
                }
            }else {
                $usdtVal=null;
                $path = base_path() . '/storage/logs/test/';

                if ($currencyName=="USDT" || $currencyName=="USDC"){
                    $usdtVal=1;
                }else{
                    $usdtVal=$this->getUsdtPriceV3($usdtPriceList,$currencyName);


                    // $path = base_path() . '/storage/logs/test/';
                    // $filename = date('Ymd') . '.log';
                    // file_exists($path) || @mkdir($path);
                    // error_log(date('Y-m-d H:i:s') .'价格='.$usdtVal. PHP_EOL, 3, $path . $filename);


                }

                $legal_balanceTmp = $walletPO->legal_balance;
                $legal_balanceTmp=doubleval($legal_balanceTmp);
                     
                if (!empty($legal_balanceTmp)&&$legal_balanceTmp>0){
                    $legal_balance=$legal_balance+bc_mul($usdtVal,$legal_balanceTmp);
                    //  $legal_balance=$legal_balance+$legal_balanceTmp;
                }

                $change_balanceTmp = $walletPO->change_balance;
                if (!empty($change_balanceTmp)&&$change_balanceTmp>0){
                    $change_balance=$change_balance+bc_mul($usdtVal,$change_balanceTmp);
                    //  $change_balance=$change_balance+$change_balanceTmp;
                }

                $lever_balanceTmp = $walletPO->lever_balance;
                // var_dump($lever_balanceTmp);
                if (!empty($lever_balanceTmp)&&$lever_balanceTmp>0){
                    $lever_balance=$lever_balance+bc_mul($usdtVal,$lever_balanceTmp);
                    // $lever_balance=$lever_balance+$lever_balanceTmp;
                }

                $earn_balanceTmp = $walletPO->earn_balance;
                if (!empty($earn_balanceTmp)&&$earn_balanceTmp>0){
                    $earn_balance=$earn_balance+bc_mul($usdtVal,$earn_balanceTmp);
                    // $earn_balance=$earn_balance+$earn_balanceTmp;
                }


                $micro_balanceTmp = $walletPO->micro_balance;
                if (!empty($micro_balanceTmp)&&$micro_balanceTmp>0){
                    $micro_balance=$micro_balance+bc_mul($usdtVal,$micro_balanceTmp);
                    // $micro_balance=$micro_balance+$micro_balanceTmp;
                }
            }


        }

        $allUsdt=$earn_balance+$legal_balance+$change_balance+$lever_balance+$micro_balance;
        $wallet_data = [
            'allUsdt'=>$allUsdt,
            'earn_balance' => $earn_balance,
            'legal_balance' => $legal_balance,
            'change_balance' => $change_balance,
            'lever_balance' => $lever_balance,
            'micro_balance' => $micro_balance,


        ];
        //Cache::put($cache_key_name, $wallet_data, 60);
        //  }
        return $this->success($wallet_data);
    }

}