<?php

namespace App\Console\Commands;


use Illuminate\Console\Command;
use App\BlockChain\Coin\CoinManager;
use App\Models\{Users, UsersWallet,LockMining,LockMiningOrder,AccountLog,WalletLog};
use Illuminate\Support\Facades\DB;
class LockMiningPlan extends Command
{
    protected $signature = 'do_lockmining';
    protected $description = '执行锁仓挖矿';


    public function handle()
    {
        $this->doLockmining();
      
    }
    /*
        每分钟执行一次
    */
    
    public function doLockmining(){
       
        db::table('lock_mining_order')->where('status',0)->orderBy('id','asc')->chunk(100, function ($lockmining) {
            $lockmining = json_decode(json_encode($lockmining), true);
            foreach ($lockmining as $val) {
                try{

                    $this->info("开始结算锁仓挖矿===>");

                    $day = intval($val['day']) * 86400;
                    $day=intval($day);
                    $created_at=intval($val['created_at']);
                    
                    
                    // 测试start
                    
                    // if($val['user_id'] == 1203449) {
                    //     $this->info("我的开始了===>");
                    //     $wallet = UsersWallet::where('user_id',$val['user_id'])->where('currency', $val['from_name'])->first();
                    //     $number = $val['money'];
                    //     change_wallet_balance($wallet, 4, $number, AccountLog::RELEASE_LOCK_MINING, '释放锁仓挖矿增加可用资产','Release lock up mining to increase available assets');
                    //     $this->info("释放锁仓挖矿增加可用资产===>".$number);
                    //     //还有进行收益
                    //     $wallet = UsersWallet::where('user_id',$val['user_id'])->where('currency', $val['to_name'])->first();
                    //     $number = $val['money'] * $val['rate'] * $val['day'] * 0.01;
                    //     $this->info("锁仓挖矿收益888===>".$number);
                    //     change_wallet_balance($wallet, 4, $number, AccountLog::LOCK_MINING_PROFIT, '锁仓挖矿收益', 'Lock up mining profits');
                    //     LockMiningOrder::where('id',$val['id'])->update(['status' => 1,'complete_at' => time()]);
                    // }
                    
                    // 测试end
                    
                    
                  if($created_at+$day <= time()){
                      $this->info("开始结算锁仓挖矿===>$created_at".$created_at."day===".$day);
                    //     //进行处理
                    
                        $wallet = UsersWallet::where('user_id',$val['user_id'])->where('currency', $val['from_name'])->first();
                      
                      
                        $number = $val['money'];
                        change_wallet_balance($wallet, 4, $number, AccountLog::RELEASE_LOCK_MINING, '释放锁仓挖矿增加可用资产','Release lock up mining to increase available assets');
                        // $this->change_wallet_balance($wallet, 2, $number, AccountLog::RELEASE_LOCK_MINING, '释放锁仓挖矿增加可用资产','Release lock up mining to increase available assets');
                        //$this->change_wallet_balance($wallet, 2, -$number, AccountLog::RELEASE_LOCK_MINING, '释放锁仓挖矿扣除冻结资产',34,true);
                        //还有进行收益
                        $wallet = UsersWallet::where('user_id',$val['user_id'])->where('currency', $val['to_name'])->first();
                        $number = $val['money'] * $val['rate'] * $val['day'] * 0.01;
                        // change_wallet_lock_balance($wallet, 4, $number, AccountLog::LOCK_MINING_PROFIT, '锁仓挖矿收益', 'Lock up mining profits', true);
                        // 改
                         change_wallet_balance($wallet, 4, $number, AccountLog::LOCK_MINING_PROFIT, '锁仓挖矿收益', 'Lock up mining profits');
                      LockMiningOrder::where('id',$val['id'])->update(['status' => 1,'complete_at' => time()]);
                        
                     }
                }catch(\Excption $e){
                    $this->error($e->getMessage());
                    
                }
            }
        });
    }
    


    function change_wallet_balance(&$wallet, $balance_type, $change, $account_log_type, $memo = '',$enmemo = '', $is_lock = false, $from_user_id = 0, $extra_sign = 0, $extra_data = '', $zero_continue = false, $overflow = false)
    {
   
  
    
    $param = compact('balance_type', 'change', 'account_log_type', 'memo', 'enmemo', 'is_lock', 'from_user_id', 'extra_sign', 'extra_data', 'zero_continue', 'overflow');
       
       
                extract($param);
                $fields = [
                    '',
                    'legal_balance',
                    'change_balance',
                    'lever_balance',
                    'micro_balance',
                    'insurance_balance'
                ];
                $field = ($is_lock ? 'lock_' : '') . $fields[$balance_type];
                $wallet = $wallet->lockForUpdate()->findOrFail($wallet->getKey()); //钱包获取最新钱包数据并锁定
                $user_id = $wallet->user_id;
                $before = $wallet->$field;
                $after = bc_add($before, $change);
                if(bc_comp($after, '0') >= 0 ){
                    $now = time();
                    AccountLog::unguard();
                    $account_log = AccountLog::create([
                        'user_id' => $user_id,
                        'value' => $change,
                        'info' => $memo,
                        'en_info' => $enmemo,
                        'type' => $account_log_type,
                        'created_time' => $now,
                        'currency' => $wallet->currency,
                    ]);
                    WalletLog::unguard();
                    $wallet_log = WalletLog::create([
                        'account_log_id' => $account_log->id,
                        'user_id' => $user_id,
                        'from_user_id' => $from_user_id,
                        'wallet_id' => $wallet->id,
                        'balance_type' => $balance_type,
                        'lock_type' => $is_lock ? 1 : 0,
                        'before' => $before,
                        'change' => $change,
                        'after' => $after,
                        'memo' => $memo,
                        'en_memo' => $enmemo ,
                        'extra_sign' => $extra_sign,
                        'extra_data' => $extra_data,
                        'create_time' => $now,
                    ]);
                    $wallet->$field = $after;
                    $result = $wallet->save();
                
                }

        }
            

}
