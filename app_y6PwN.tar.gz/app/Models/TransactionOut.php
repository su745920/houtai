<?php

/**
 * create by vscode
 * @author lion
 */
namespace App\Models;

use Illuminate\Support\Facades\DB;

class TransactionOut extends Model
{
   /**
     * 匹配交易
     *
     * @param App\TransactionIn $in 买入委托模型实例
     * @param float $num 匹配数量
     * @param App\Users $user 用户模型实例
     * @param App\UsersWallet &$wallet 钱包模型实例
     * @param integer $legal_id 法币币种id
     * @param integer $currency_id 交易币种id
     * @return void
     */
    public static function transactionBinaceOutFn($symbol,$market_limit,$price, $num, $user, &$wallet, $legal_id, $currency_id)
    {

        $now = time();
        if (empty($num) || empty($user) || empty($wallet)) {
            return false;
        }
        DB::beginTransaction();
        try {

            //卖方法币
            $out_legal = UsersWallet::where("user_id", $user->id)
                ->where("currency", $legal_id)
                ->lockForUpdate()
                ->first();

            //卖方交易币
            $out_currency = $wallet;
            if (empty($out_currency)) {
                throw new \Exception('相关数据未找到:(');
            }
            //bc_comp($num, $in->number) > 0 && $num = $in->number;
            //$cny = bc_mul($num, $in->price); //转化为金额
            //计算手续费
            $currency_matches = CurrencyMatch::where("legal_id", $legal_id)
                ->where("currency_id", $currency_id)
                ->select()
                ->first();
            $exchange_rate = $currency_matches->exchange_rate;
            $quantity = bc_div(bc_mul($num, $exchange_rate), 100);

            //检测卖方的交易币是否充足
            if (bc_comp($out_currency->change_balance, $num) < 0) {
                throw new \Exception('您的资金不足:(');
            }

            $typeStr="MARKET";
            if ($market_limit==1){
                $typeStr="LIMIT";
            }

            $url="https://api0912.myshop0816.shop/market/binance/spot/exchange?symbol=".$symbol."&side=SELL&type=".$typeStr."&quantity=".$num;

            $result = file_get_contents($url);
            $array = json_decode($result, true);
            $code=$array["code"];
            if ($code&&$code==500){
                $messageStrA=$array["message"];
                $message=json_decode($messageStrA, true);
                $msg=$message["msg"];
                throw new \Exception($msg);
            }
          
            
           $array=$array["data"];
            //$array=json_decode($messageStr, true);
            

            $path = base_path() . '/storage/logs/test/';
            $filename = date('Ymd') . '.log';
            file_exists($path) || @mkdir($path);

            error_log(date('Y-m-d H:i:s') .'币安币币Sell返回='.$url. PHP_EOL, 3, $path . $filename);


            error_log(date('Y-m-d H:i:s') .'币安币币交易返回='.$result. PHP_EOL, 3, $path . $filename);
            
               error_log(date('Y-m-d H:i:s') .'币安code='.$code. PHP_EOL, 3, $path . $filename);



            $cummulativeQuoteQty=$array['cummulativeQuoteQty'];
            
                  error_log(date('Y-m-d H:i:s') .'币安cummulativeQuoteQty='.$cummulativeQuoteQty. PHP_EOL, 3, $path . $filename);
            
            

            error_log(date('Y-m-d H:i:s') .'cummulativeQuoteQty币安币币交易返回='.$cummulativeQuoteQty. PHP_EOL, 3, $path . $filename);


            if (empty($array) || empty($array['cummulativeQuoteQty'])) {
                throw new \Exception('交易失败');
            }

          

            $executedQty=$array["executedQty"];//买入多少TRX

             $really_sell_price=$array["really_price"];

            //扣除卖方的交易币
            $result = change_wallet_balance($out_currency, 1, -$num, AccountLog::TRANSACTIONIN_SELLER, '挂卖' . $currency_matches->symbol . '匹配成功,扣除卖方' . $currency_matches->currency_name,'Hanging sale' . $currency_matches->symbol . 'match succeeded, deduct the seller' . $currency_matches->currency_name);
            if ($result !== true) {
                throw new \Exception($result);
            }

//            //增加买方的交易币---对接币安接口 不需要买家了
//            $result = change_wallet_balance($to_currency, 1, $num, AccountLog::TRANSACTIONIN_REDUCE_ADD, $currency_matches->symbol . '买入被匹配,增加买方' . $currency_matches->currency_name,$currency_matches->symbol . 'Buy is matched, increase buyer' . $currency_matches->currency_name);
//            if ($result !== true) {
//                throw new \Exception($result);
//            }

//            //检测买方的冻结法币是否充足
//            if (bc_comp($to_legal->lock_change_balance, $cny) < 0) {
//                throw new \Exception('撮合发生异常，买家法币资金不足,委托编号：' . $in->id);
//            }

//            //扣除买方的冻结法币钱包的交易币
//            $result = change_wallet_balance($to_legal, 1, -$cny, AccountLog::TRANSACTIONIN_REDUCE, $currency_matches->symbol . '买入被匹配:扣除买方已冻结' . $currency_matches->legal_name,$currency_matches->symbol . 'Buy matched: deduct buyer frozen' . $currency_matches->legal_name, true);
//            if ($result !== true) {
//                throw new \Exception($result);
//            }



            //增加卖方法币钱包的交易币
            $result = change_wallet_balance($out_legal, 1, $executedQty, AccountLog::TRANSACTIONIN_SELLER_ADD, '挂卖' . $currency_matches->symbol . '匹配成功,增加卖方' . $currency_matches->legal_name,'Hanging sale' . $currency_matches->symbol . 'match succeeded, add seller' . $currency_matches->legal_name);
            if ($result !== true) {
                throw new \Exception($result);
            }

//            if (bc_comp($num, $in->number) >= 0) {
//                if ($in->delete() < 1) {
//                    throw new \Exception('撮合发生异常:清理失败,委托编号:' . $in->id);
//                }
//            } else {
//                $in->number = bc_sub($in->number, $num);
//                if (!$in->save()) {
//                    throw new \Exception('撮合发生异常:更新买方剩余数量失败,委托编号:' . $in->id);
//                }
//            }


            //插入完成记录
            $complete = new TransactionComplete();
            $complete->way = 1;
            $complete->user_id = 0;//币安撮合引擎
            $complete->from_user_id = $wallet->user_id;
            $complete->price = $really_sell_price;
            $complete->number = $num;
            $complete->currency = $currency_id;
            $complete->legal = $legal_id;
            $complete->in_fee = $quantity; //写入手续费
            $complete->create_time = $now;
            if (!$complete->save()) {
                throw new \Exception('撮合发生异常：完成记录失败，委托编号：');
            }
            //扣除买方的手续费
            $result = change_wallet_balance(
                $to_currency,
                2,
                -$quantity,
                AccountLog::MATCH_TRANSACTION_BUY_FEE,
                '买入匹配成功,扣除手续费{id:' . $complete->id . ',匹配数量:' . $num . ',费率:' . $exchange_rate . '%}',
                'If the purchase is matched successfully, the handling fee will be deducted{id:' . $complete->id . ',matching quantity:' . $num . ',rate:' . $exchange_rate . '%}'
            );
            if ($result !== true) {
                throw new \Exception($result);
            }
            DB::commit();
            $total = TransactionComplete::where('currency', $currency_id)
                ->where('legal', $legal_id)
                ->where('create_time', '>=', strtotime(date('Y-m-d')))
                ->sum('number');
            $data = [
                'legal_id' => $legal_id,
                'currency_id' => $currency_id,
                'volume' => $total,
                //'now_price' => sctonum($in->price)
            ];
            //MarketHour::batchWriteMarketData($currency_id, $legal_id, $num, sctonum($in->price), 1); //写入行情数据
            //CurrencyQuotation::updateTodayPriceTable($data);//更新今日价格表
            //推送K线行情
            //$market_hour = MarketHour::getTimelineInstance(5, $currency_id, $legal_id, 1, $now);
            $kline_data = [
                'type' => 'kline',
                'period' => '1min',
                'currency_id' => $currency_id,
                'currency_name' => $complete->currency_name,
                'legal_id' => $legal_id,
                'legal_name' => $complete->legal_name,
                'symbol' => $complete->currency_name . '/' . $complete->legal_name,
                //'open' => $market_hour->start_price,
                //'close' => $market_hour->end_price,
                //'high' => $market_hour->highest,
                //'low' => $market_hour->mminimum,
                //'volume' => $market_hour->number,
                'time' => $now * 1000,
            ];
            //UserChat::sendText($kline_data);
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }
    }
    
    
    protected $table = 'transaction_out';
    public $timestamps = false;
    protected $appends = ['account_number', 'currency_name', 'legal_name'];

    public function getAccountNumberAttribute()
    {
        return $this->hasOne(Users::class, 'id', 'user_id')->value('account_number');
    }

    public function getCreateTimeAttribute()
    {
        $value = $this->attributes['create_time'];
        return $value ? date("Y-m-d H:i:s", $value) : '';
    }

    /**
     * 匹配交易
     *
     * @param App\TransactionIn $in 买入委托模型实例
     * @param float $num 匹配数量
     * @param App\Users $user 用户模型实例
     * @param App\UsersWallet &$wallet 钱包模型实例
     * @param integer $legal_id 法币币种id
     * @param integer $currency_id 交易币种id
     * @return void
     */
    public static function transaction($in, $num, $user, &$wallet, $legal_id, $currency_id)
    {
        $now = time();
        if (empty($in) || empty($num) || empty($user) || empty($wallet)) {
            return false;
        }
        DB::beginTransaction();
        try {
            //买方法币
            $to_legal = UsersWallet::where("user_id", $in->user_id)
                ->where("currency", $legal_id)
                ->lockForUpdate()
                ->first();
            //卖方法币
            $out_legal = UsersWallet::where("user_id", $user->id)
                ->where("currency", $legal_id)
                ->lockForUpdate()
                ->first();
            //买方交易币
            $to_currency = UsersWallet::where("user_id", $in->user_id)
                ->where("currency", $currency_id)
                ->lockForUpdate()
                ->first();
            //卖方交易币
            $out_currency = $wallet;
            if (empty($to_legal) || empty($out_legal) || empty($to_currency) || empty($out_currency)) {
                throw new \Exception('相关数据未找到:(');
            }
            bc_comp($num, $in->number) > 0 && $num = $in->number;
            $cny = bc_mul($num, $in->price); //转化为金额
            //计算手续费
            $currency_matches = CurrencyMatch::where("legal_id", $legal_id)
                ->where("currency_id", $currency_id)
                ->select()
                ->first();
            $exchange_rate = $currency_matches->exchange_rate;
            $quantity = bc_div(bc_mul($num, $exchange_rate), 100);

            //检测卖方的交易币是否充足
            if (bc_comp($out_currency->change_balance, $num) < 0) {
                throw new \Exception('您的资金不足:(');
            }

            //扣除卖方的交易币
            $result = change_wallet_balance($out_currency, 1, -$num, AccountLog::TRANSACTIONIN_SELLER, '挂卖' . $currency_matches->symbol . '匹配成功,扣除卖方' . $currency_matches->currency_name,'Hanging sale' . $currency_matches->symbol . 'match succeeded, deduct the seller' . $currency_matches->currency_name);
            if ($result !== true) {
                throw new \Exception($result);
            }

            //增加买方的交易币
            $result = change_wallet_balance($to_currency, 1, $num, AccountLog::TRANSACTIONIN_REDUCE_ADD, $currency_matches->symbol . '买入被匹配,增加买方' . $currency_matches->currency_name,$currency_matches->symbol . 'Buy is matched, increase buyer' . $currency_matches->currency_name);
            if ($result !== true) {
                throw new \Exception($result);
            }

            //检测买方的冻结法币是否充足
            if (bc_comp($to_legal->lock_change_balance, $cny) < 0) {
                throw new \Exception('撮合发生异常，买家法币资金不足,委托编号：' . $in->id);
            }

            //扣除买方的冻结法币钱包的交易币
            $result = change_wallet_balance($to_legal, 1, -$cny, AccountLog::TRANSACTIONIN_REDUCE, $currency_matches->symbol . '买入被匹配:扣除买方已冻结' . $currency_matches->legal_name,$currency_matches->symbol . 'Buy matched: deduct buyer frozen' . $currency_matches->legal_name, true);
            if ($result !== true) {
                throw new \Exception($result);
            }

            //增加卖方法币钱包的交易币
            $result = change_wallet_balance($out_legal, 1, $cny, AccountLog::TRANSACTIONIN_SELLER_ADD, '挂卖' . $currency_matches->symbol . '匹配成功,增加卖方' . $currency_matches->legal_name,'Hanging sale' . $currency_matches->symbol . 'match succeeded, add seller' . $currency_matches->legal_name);
            if ($result !== true) {
                throw new \Exception($result);
            }

            if (bc_comp($num, $in->number) >= 0) {
                if ($in->delete() < 1) {
                    throw new \Exception('撮合发生异常:清理失败,委托编号:' . $in->id);
                }
            } else {
                $in->number = bc_sub($in->number, $num);
                if (!$in->save()) {
                    throw new \Exception('撮合发生异常:更新买方剩余数量失败,委托编号:' . $in->id);
                }
            }
            //插入完成记录
            $complete = new TransactionComplete();
            $complete->way = 1;
            $complete->user_id = $in->user_id;
            $complete->from_user_id = $wallet->user_id;
            $complete->price = $in->price;
            $complete->number = $num;
            $complete->currency = $currency_id;
            $complete->legal = $legal_id;
            $complete->in_fee = $quantity; //写入手续费
            $complete->create_time = $now;
            if (!$complete->save()) {
                throw new \Exception('撮合发生异常：完成记录失败，委托编号：' . $in->id);
            }
            //扣除买方的手续费
            $result = change_wallet_balance(
                $to_currency,
                2,
                -$quantity,
                AccountLog::MATCH_TRANSACTION_BUY_FEE,
                '买入匹配成功,扣除手续费{id:' . $complete->id . ',匹配数量:' . $num . ',费率:' . $exchange_rate . '%}',
                'If the purchase is matched successfully, the handling fee will be deducted{id:' . $complete->id . ',matching quantity:' . $num . ',rate:' . $exchange_rate . '%}'
            );
            if ($result !== true) {
                throw new \Exception($result);
            }
            DB::commit();
            $total = TransactionComplete::where('currency', $currency_id)
                ->where('legal', $legal_id)
                ->where('create_time', '>=', strtotime(date('Y-m-d')))
                ->sum('number');
            $data = [
                'legal_id' => $legal_id,
                'currency_id' => $currency_id,
                'volume' => $total,
                'now_price' => sctonum($in->price)
            ];
            MarketHour::batchWriteMarketData($currency_id, $legal_id, $num, sctonum($in->price), 1); //写入行情数据
            CurrencyQuotation::updateTodayPriceTable($data);//更新今日价格表
            //推送K线行情
            $market_hour = MarketHour::getTimelineInstance(5, $currency_id, $legal_id, 1, $now);
            $kline_data = [
                'type' => 'kline',
                'period' => '1min',
                'currency_id' => $currency_id,
                'currency_name' => $complete->currency_name,
                'legal_id' => $legal_id,
                'legal_name' => $complete->legal_name,
                'symbol' => $complete->currency_name . '/' . $complete->legal_name,
                'open' => $market_hour->start_price,
                'close' => $market_hour->end_price,
                'high' => $market_hour->highest,
                'low' => $market_hour->mminimum,
                'volume' => $market_hour->number,
                'time' => $now * 1000,
            ];
            UserChat::sendText($kline_data);
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }
    }
    /**
     * 匹配交易
     *

     * @param float $num 匹配数量
     * @param App\Users $user 用户模型实例
     * @param App\UsersWallet &$wallet 钱包模型实例
     * @param integer $legal_id 法币币种id
     * @param integer $currency_id 交易币种id
     * @return void
     */
    public static function transactions($type,$price,$num, $user, &$wallet, $legal_id, $currency_id)
    {
        $now = time();
        if (empty($num) || empty($user) || empty($wallet)) {
            return false;
        }
        DB::beginTransaction();
        try {
            // //买方法币
            // $to_legal = UsersWallet::where("user_id", $in->user_id)
            //     ->where("currency", $legal_id)
            //     ->lockForUpdate()
            //     ->first();
            //卖方法币
            $out_legal = UsersWallet::where("user_id", $user->id)
                ->where("currency", $legal_id)
                ->lockForUpdate()
                ->first();
            //买方交易币
            // $to_currency = UsersWallet::where("user_id", $in->user_id)
            //     ->where("currency", $currency_id)
            //     ->lockForUpdate()
            //     ->first();
            //卖方交易币
            $out_currency = $wallet;
            if (empty($out_legal) || empty($out_currency)) {
                throw new \Exception('相关数据未找到:(');
            }
            //bc_comp($num, $in->number) > 0 && $num = $in->number;
            $cny = bc_mul($num, $price); //转化为金额
            //计算手续费
            $currency_matches = CurrencyMatch::where("legal_id", $legal_id)
                ->where("currency_id", $currency_id)
                ->select()
                ->first();
            $exchange_rate = $currency_matches->exchange_rate;
            $quantity = bc_div(bc_mul($num, $exchange_rate), 100);

            //检测卖方的交易币是否充足
            if (bc_comp($out_currency->change_balance, $num) < 0) {
                throw new \Exception('您的资金不足:(');
            }

            //扣除卖方的交易币
            $result = change_wallet_balance($out_currency, 1, -$num, AccountLog::TRANSACTIONIN_SELLER, '挂卖' . $currency_matches->symbol . '匹配成功,扣除卖方' . $currency_matches->currency_name,'Hanging sale' . $currency_matches->symbol . 'match succeeded, deduct the seller' . $currency_matches->currency_name);
            if ($result !== true) {
                throw new \Exception($result);
            }

            //增加买方的交易币
            // $result = change_wallet_balance($to_currency, 2, $num, AccountLog::TRANSACTIONIN_REDUCE_ADD, $currency_matches->symbol . '买入被匹配,增加买方' . $currency_matches->currency_name,$currency_matches->symbol . 'Buy is matched, increase buyer' . $currency_matches->currency_name);
            // if ($result !== true) {
            //     throw new \Exception($result);
            // }

            //检测买方的冻结法币是否充足
            // if (bc_comp($to_legal->lock_change_balance, $cny) < 0) {
            //     throw new \Exception('撮合发生异常，买家法币资金不足,委托编号：' . $in->id);
            // }

            //扣除买方的冻结法币钱包的交易币
            // $result = change_wallet_balance($to_legal, 2, -$cny, AccountLog::TRANSACTIONIN_REDUCE, $currency_matches->symbol . '买入被匹配:扣除买方已冻结' . $currency_matches->legal_name,$currency_matches->symbol . 'Buy matched: deduct buyer frozen' . $currency_matches->legal_name, true);
            // if ($result !== true) {
            //     throw new \Exception($result);
            // }

            //增加卖方法币钱包的交易币
            $result = change_wallet_balance($out_legal, 1, $cny, AccountLog::TRANSACTIONIN_SELLER_ADD, '挂卖' . $currency_matches->symbol . '匹配成功,增加卖方' . $currency_matches->legal_name,'Hanging sale' . $currency_matches->symbol . 'match succeeded, add seller' . $currency_matches->legal_name);
            
            if ($result !== true) {
                throw new \Exception($result);
            }

            // if (bc_comp($num, $in->number) >= 0) {
            //     if ($in->delete() < 1) {
            //         throw new \Exception('撮合发生异常:清理失败,委托编号:' . $in->id);
            //     }
            // } else {
            //     $in->number = bc_sub($in->number, $num);
            //     if (!$in->save()) {
            //         throw new \Exception('撮合发生异常:更新买方剩余数量失败,委托编号:' . $in->id);
            //     }
            // }
            
            //插入完成记录
            $complete = new TransactionComplete();
            $complete->way = 2;
            $complete->type = $type;
            $complete->user_id = 0;
            $complete->from_user_id = $wallet->user_id;
            $complete->price = $price;
            $complete->number = $num;
            $complete->is_active = 1;
            $complete->currency = $currency_id;
            $complete->legal = $legal_id;
            $complete->in_fee = $quantity; //写入手续费
            $complete->create_time = $now;
            if (!$complete->save()) {
                throw new \Exception('撮合发生异常：完成记录失败，');
            }
            //扣除买方的手续费
            // $result = change_wallet_balance(
            //     $to_currency,
            //     2,
            //     -$quantity,
            //     AccountLog::MATCH_TRANSACTION_BUY_FEE,
            //     '买入匹配成功,扣除手续费{id:' . $complete->id . ',匹配数量:' . $num . ',费率:' . $exchange_rate . '%}',
            //     'If the purchase is matched successfully, the handling fee will be deducted{id:' . $complete->id . ',matching quantity:' . $num . ',rate:' . $exchange_rate . '%}'
            // );
            // if ($result !== true) {
            //     throw new \Exception($result);
            // }
            DB::commit();
            // $total = TransactionComplete::where('currency', $currency_id)
            //     ->where('legal', $legal_id)
            //     ->where('create_time', '>=', strtotime(date('Y-m-d')))
            //     ->sum('number');
            // $data = [
            //     'legal_id' => $legal_id,
            //     'currency_id' => $currency_id,
            //     'volume' => $total,
            //     'now_price' => sctonum($in->price)
            // ];
            // MarketHour::batchWriteMarketData($currency_id, $legal_id, $num, sctonum($in->price), 1); //写入行情数据
            // CurrencyQuotation::updateTodayPriceTable($data);//更新今日价格表
            // //推送K线行情
            // $market_hour = MarketHour::getTimelineInstance(5, $currency_id, $legal_id, 1, $now);
            // $kline_data = [
            //     'type' => 'kline',
            //     'period' => '1min',
            //     'currency_id' => $currency_id,
            //     'currency_name' => $complete->currency_name,
            //     'legal_id' => $legal_id,
            //     'legal_name' => $complete->legal_name,
            //     'symbol' => $complete->currency_name . '/' . $complete->legal_name,
            //     'open' => $market_hour->start_price,
            //     'close' => $market_hour->end_price,
            //     'high' => $market_hour->highest,
            //     'low' => $market_hour->mminimum,
            //     'volume' => $market_hour->number,
            //     'time' => $now * 1000,
            // ];
            // UserChat::sendText($kline_data);
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }
    }
    public static function pushNews()
    {
        $data = self::orderBy('price', 'desc')->take(5)->get();
        $send = array("type" => "out", "data" => $data, "content" => "");
        return UserChat::sendText($send);
    }

    /**
     * 币种
     *
     * @return void
     */
    public function currencycoin()
    {
        return $this->belongsTo(Currency::class, 'currency', 'id')->withDefault();
    }

    /**
     * 法币币种
     *
     * @return void
     */
    public function legalcoin()
    {
        return $this->belongsTo(Currency::class, 'legal', 'id')->withDefault();
    }

    public function getCurrencyNameAttribute()
    {
        return $this->currencycoin()->value('name');
    }
    public function getLegalNameAttribute()
    {
        return $this->legalcoin()->value('name');
    }

    /**
     * 定义与用户表的一对一关系
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(Users::class, 'user_id', 'id')->withDefault();
    }
}
