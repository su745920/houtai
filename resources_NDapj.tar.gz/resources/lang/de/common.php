<?php

return [

  'cg' => 'success',
     'tjcg' => 'submitted successfully',
     'tjsb' => 'Failed to submit',
     'cscw' => 'parameter error',
     'success' => 'success',
     'fail' => 'fail',
     'error' => 'error',
     'xwbcz' => 'News does not exist',
     'sjwzd' => 'data not found',
     'nrbnwk' => 'The content cannot be empty',
     'tjcgwmhjkgnhf' => 'Submitted successfully, we will reply to you as soon as possible',
     'dkbcz' => 'The loan does not exist',
     'stop' => 'Markt geschlossen, Handel ausgesetzt',
     'again' => 'Bitte schließen Sie die vorherige Transaktion ab, bevor Sie mit der Transaktion fortfahren',
];
