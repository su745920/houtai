@extends('admin._layoutNew')

@section('page-head')
<style>
    .order_type_rise {
        /*
        background-color:#89deb3;
        */
        color:#1aab65;
    }
    .order_type_fall {
        /*
        background-color:#d67a7a;
        */
        color:#de1919;
    }
    .order_type {
        /*
        color:#fff;
        */
        font-size: 10px;
        text-align: center;
    }
    .layui-item {
        margin: 10px;
    }
    .hidden {
        display: none;
    }
</style>
@endsection

@section('page-content')
<div class="layui-form">
    @if(strpos($authorityList,"3005")>0)
     <button class="layui-btn layui-btn-primary" id="newsAdd">添加锁仓挖矿</button>
        @endif

    <!--<div class="layui-item">-->
    <!--    <div class="layui-inline" style="margin-left: 10px;">-->
    <!--    </div>-->
    <!--  
    <!--    <div class="layui-inline" style="margin-left: 10px;">-->
    <!--        <label>买卖类型</label>-->
    <!--        <div class="layui-input-inline" style="width: 90px">-->
    <!--            <select name="type" id="type" class="layui-input">-->
    <!--                <option value="-1">所有</option>-->
    <!--                <option value="1">买涨</option>-->
    <!--                <option value="2">买跌</option>-->
    <!--            </select>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--    <div class="layui-inline" style="margin-left: 10px;">-->
    <!--        <label>保险交易</label>-->
    <!--        <div class="layui-input-inline" style="width: 90px">-->
    <!--            <select name="is_insurance" id="is_insurance" class="layui-input">-->
    <!--                <option value="-1">所有</option>-->
    <!--                <option value="2">反向</option>-->
    <!--                <option value="1">正向</option>-->
    <!--                <option value="0">否</option>-->
    <!--            </select>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--    <div class="layui-inline" style="margin-left: 10px;">-->
    <!--        <label>交易状态</label>-->
    <!--        <div class="layui-input-inline" style="width: 90px">-->
    <!--            <select name="status" id="status" class="layui-input">-->
    <!--                <option value="-1">所有</option>-->
    <!--                <option value="1">交易中</option>-->
    <!--                <option value="2">平仓中</option>-->
    <!--                <option value="3">已平仓</option>-->
    <!--            </select>-->
    <!--        </div>-->
    <!--    </div>-->
        <!--<div class="layui-inline" style="margin-left: 10px;">-->
        <!--    <label>预设</label>-->
        <!--    <div class="layui-input-inline" style="width: 90px">-->
        <!--        <select name="pre_profit_result" id="pre_profit_result" class="layui-input">-->
        <!--            <option value="-2">所有</option>-->
        <!--            <option value="-1">亏</option>-->
        <!--            <option value="0">无</option>-->
        <!--            <option value="1">盈</option>-->
        <!--        </select>-->
        <!--    </div>-->
        <!--    <button class="layui-btn layui-btn-primary" id="btn-set" type="button" style="padding:0px; margin-left: -4px; width: 30px;">-->
        <!--        <i class="layui-icon layui-icon-set-fill"></i>-->
        <!--    </button>-->
        <!--</div>-->
    <!--    <div class="layui-inline" style="margin-left: 10px;">-->
    <!--        <label>结果</label>-->
    <!--        <div class="layui-input-inline" style="width: 90px">-->
    <!--            <select name="profit_result" id="profit_result" class="layui-input">-->
    <!--                <option value="-2">所有</option>-->
    <!--                <option value="-1">亏</option>-->
    <!--                <option value="0">无</option>-->
    <!--                <option value="1">盈</option>-->
    <!--            </select>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--    <div class="layui-btn-group">-->
    <!--        <button class="layui-btn layui-btn-primary" id="spread" type="button" style="padding:0px; width: 30px;"><i class="layui-icon layui-icon-down"></i></button>-->
    <!--        <button class="layui-btn" id="btn-search" lay-submit lay-filter="btn-search"><i class="layui-icon layui-icon-search"></i></button>-->
    <!--    </div>-->
        
    <!--</div>-->

    <!--<div class="layui-item hidden" id="more">-->
    <!--    <div class="layui-inline" style="margin-left: 10px;">-->
    <!--        <label >开始日期：</label>-->
    <!--        <div class="layui-input-inline" style="width:170px;">-->
    <!--            <input type="text" class="layui-input" id="start_time" value="" name="start_time">-->
    <!--        </div>-->
    <!--    </div>-->
    <!--    <div class="layui-inline" style="margin-left: 10px;">-->
    <!--        <label >结束日期：</label>-->
    <!--        <div class="layui-input-inline" style="width:170px;">-->
    <!--            <input type="text" class="layui-input" id="end_time" value="" name="end_time">-->
    <!--        </div>-->
    <!--    </div>-->
    <!--    <div class="layui-inline" style="margin-left: 10px;">-->
    <!--        <label>用户账号</label>-->
    <!--        <div class="layui-input-inline">-->
    <!--            <input type="text" name="account" placeholder="请输入手机号或邮箱" autocomplete="off" class="layui-input" value="">-->
    <!--        </div>-->
    <!--    </div>-->
    <!--    <div class="layui-inline" style="margin-left: 10px;">-->
    <!--        <label>真实姓名</label>-->
    <!--        <div class="layui-input-inline">-->
    <!--            <input type="text" name="name" placeholder="请输入真实姓名" autocomplete="off" class="layui-input" value="">-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
</div>

<table id="order_list" lay-filter="order_list"></table>
@endsection

@section('scripts')
<script type="text/html" id="barDemo">
    @if(strpos($authorityList,"3003")>0)
       @{{d.status==1 ? '<a class="layui-btn layui-btn-xs layui-btn-warm" lay-event="edit">编辑</a>' : '' }}
    @endif

    @if(strpos($authorityList,"3004")>0)
        <a class="layui-btn layui-btn-xs layui-btn-danger" lay-event="del">删除</a>
    @endif
</script>

<script type="text/html" id="type_name">
    @{{# if (d.type == 1) { }}
        <div class="order_type order_type_rise">
            <span style="font-size: 13px; font-weight: bold;">@{{d.type_name}}</span><span style="font-size: 18px; font-weight: bold;">↑</span> 
        </div>
    @{{# } else { }}
        <div class="order_type order_type_fall">
            <span style="font-size: 13px; font-weight: bold;">@{{d.type_name}}</span><span style="font-size: 18px; font-weight: bold;">↓</span>
        </div>
    @{{# } }}
</script>

<script type="text/html" id="pre_profit_result_name">
    @{{# if (d.pre_profit_result == 1) { }}
        <span style="color:#89deb3;">@{{d.pre_profit_result_name}}</span>
    @{{# } else if (d.pre_profit_result == -1) { }}
        <span style="color:#d67a7a;">@{{d.pre_profit_result_name}}</span>
    @{{# } else { }}
        <span class="layui-badge-rim">@{{d.pre_profit_result_name}}</span>
    @{{# } }}
</script>


<script type="text/html" id="switchTpl">
    <input type="checkbox" name="status" value="@{{d.id}}" lay-skin="switch" lay-text="正常|禁止" lay-filter="status" @{{ d.status == 1 ? 'checked' : '' }}>
</script>


<script type="text/html" id="symbol_name">
    <span>@{{d.symbol_name}}</span><span style="color: #848484dd; font-size: 10px;" title="收益率:@{{d.profit_ratio}}%">-@{{d.seconds}}S</span>
</script>

<script type="text/html" id="seconds">
    <div>
        <span title="收益率:@{{d.profit_ratio}}%">@{{d.seconds}}</span>
    </div>
</script>

<script type="text/html" id="fact_profits">
    <div style="text-align: right; margin-right: 10px;">
    @{{# if (d.profit_result == 1) { }}
        <span style="color: #f00; font-weight: bolder;">@{{Number(d.fact_profits).toFixed(0)}}</span>
    @{{# } else { }}
        <span>@{{Number(d.fact_profits).toFixed(0)}}</span>
    @{{# } }}
    </div>
</script>

<script>
    window.onload = function() {
        document.onkeydown = function(event) {
            var e = event || window.event || arguments.callee.caller.arguments[0];
            if (e && e.keyCode == 13) { // enter 键
                $('#btn-search').click();
            }
        };
        layui.use(['element', 'form', 'layer', 'table', 'laydate'], function() {
            var element = layui.element;
            var layer = layui.layer;
            var table = layui.table;
            var $ = layui.$;
            var form = layui.form;
            var laydate = layui.laydate;
            laydate.render({
                elem: '#start_time',
                type:'datetime'
            });
            laydate.render({
                elem: '#end_time',
                type:'datetime'
            });
            form.on('submit(btn-search)', function (data) {
                var option = {
                    where: data.field,
                    page: {curr: 1}
                }
                data_table.reload(option);
                return false;
            });
            $('#spread').click(function () {
                var icon = $(this).find('i');
                var order_list_height = $('div[lay-id=order_list]').height()
                var origin_height = $('div[lay-id=order_list] div.layui-table-box').height()
                if (icon.hasClass('layui-icon-up')) {
                    $('div[lay-id=order_list]').height(order_list_height + 30)
                    $('div[lay-id=order_list] div.layui-table-box').height(origin_height + 30)
                    icon.removeClass('layui-icon-up')
                    icon.addClass('layui-icon-down')
                } else {
                    $('div[lay-id=order_list]').height(order_list_height - 30)
                    $('div[lay-id=order_list] div.layui-table-box').height(origin_height - 30)
                    icon.removeClass('layui-icon-down')
                    icon.addClass('layui-icon-up')
                }
                $('#more').toggle();
            });

            var data_table =   table.render({
                elem: '#order_list',
                url: "/admin/lock_config_index",
                done: function(res, curr, count) {
                    $('tr:has(div.order_type_rise)').css('backgroundColor', '#f4fdf8');
                    $('tr:has(div.order_type_fall)').css('backgroundColor', '#fff8f8');
                },
                page: true,
                limit: 100,
                limits: [20, 50, 100, 500, 1000],
                toolbar: true,
                height: 'full-100',
                totalRow: true,
                cols: [[
                    {field: '', type: 'checkbox', width: 60}
                    ,{field: '', title: '序号', type: "numbers", width: 90}
                    ,{field: 'id', title: 'ID', width: 100}
                    
                    ,{field: 'title', title: '级别', width: 130}
                    ,{field: 'from_name', title: '锁定币种', width: 130}
                    ,{field: 'to_name', title: '产出币种', width: 130}
                    ,{field: 'day', title: '天数', width: 130, sort: true, totalRowText: '小计'}
                    ,{field: 'rate', title: '最小收益率(%)', width: 130}
                    ,{field: 'rate_max', title: '最大收益率(%)', width: 130}
                    ,{field: 'min_money', title: '最小锁仓', width: 200}
                    ,{field: 'max_money', title: '最大锁仓', width: 200}
                    ,{field: 'adance_redeem_falsify', title: '提前赎回手续费率', width: 200}
                    ,{field: 'adance_redeem_credit', title: '提前赎回信用分', width: 200}
                    ,{field: 'status', title: '状态', width: 110, sort: true, templet: '#switchTpl', hide: false}
                   
                    ,{field: 'created_at', title: '添加时间', width: 170, sort: true}
                    ,{field: 'updated_at', title: '更新日期', width: 170, sort: true, hide: true}
                    
                    ,{fixed: 'right', title: '操作', width: 150, align: 'center', toolbar: '#barDemo'}
                ]]
            });

            //监听工具条
            table.on('tool(order_list)', function(obj) { //注：tool是工具条事件名，test是table原始容器的属性 lay-filter="对应的值"
                var data = obj.data;
                var layEvent = obj.event;
                var tr = obj.tr;
                if (layEvent === 'edit') { //编辑
                    layer_show('编辑锁仓挖矿', '/admin/lock_config_edit?id=' + data.id);
                }else if(layEvent === 'del'){
                     layer.confirm('真的删除行么?可能会导致系统崩溃！', function(index){
                         $.ajax({
                            url:'<?php echo e(url('admin/lock_del')); ?>',
                            type:'get',
                            dataType:'json',
                            data:{id:data.id},
                            success:function (res) {
                                if(res.type == 'error'){
                                    layer.msg(res.message);
                                }else{
                                
                                    obj.del();
                                
                                    layer.close(index);
                                }
                            }
                        });
            

                    });
                    
                    
                    
                    
                }
            });

            table.on('checkbox(order_list)', function(obj) {
                // 选择事件
                console.log(obj)
            });
            //监听锁定操作
            form.on('switch(status)', function(obj){
                var id = this.value;
                
                $.ajax({
                    url:'{{url('admin/lock_config_status')}}',
                    type:'post',
                    dataType:'json',
                    data:{id:id},
                    success:function (res) {
                        layer.msg(res.message);
                        
                    }
                });
            });
            $('#btn-set').click(function () {
                var checkStatus = table.checkStatus('order_list');
                var pre_profit_result = $('#pre_profit_result').val();
                var ids = [];
                try {
                    if (checkStatus.data.length <= 0) {
                        throw '请先选择交易';
                    }
                    if (pre_profit_result <= -2) {
                        throw '请选择交易的预处理风控类型';
                    }
                    checkStatus.data.forEach(function (item, index, arr) {
                        ids.push(item.id);
                    });
                    $.ajax({
                        url: '/admin/micro/batch_risk'
                        ,type: 'POST'
                        ,data: {risk: pre_profit_result, ids: ids}
                        ,success: function (res) {
                            layer.msg(res.message, {
                                time: 2000,
                                end: function () {
                                    if (res.type == 'ok') {
                                        data_table.reload();
                                    }
                                }
                            });
                        }
                        ,error: function (res) {
                            layer.msg('网络错误');
                        }
                    })
                    
                } catch (error) {
                    layer.msg(error);
                }
            });
            
            
            
              //监听工具条
            table.on('#newsAdd', function(obj) { //注：tool是工具条事件名，test是table原始容器的属性 lay-filter="对应的值"
                var data = obj.data;
                var layEvent = obj.event;
                var tr = obj.tr;
                if (layEvent === 'edit') { //编辑
                    layer_show('编辑锁仓挖矿', '/admin/lock_config_edit?id=' + data.id);
                }
            });
            
            
            
            $('#newsAdd').click(function() {
                var index = layer.open({
                    title:'添加锁仓挖矿'
                    ,type:2
                    ,content: '/admin/lock_config_add'
                    ,area: ['800px', '600px']
                    ,maxmin: true
                    ,anim: 3
                });
                layer.full(index);
                    
                    
            });
        });
    }
</script>
@endsection