@extends('admin._layoutNew')

@section('page-head')

@endsection

@section('page-content')
<div class="layui-form">
    <div class="layui-form-item">
        <div class="layui-inline">
            <label class="layui-form-label">所属版块</label>
            <div class="layui-input-inline" style="width:160px;">
                <select name="plate_id" lay-verify="required" lay-filter="plate_id">
                    <option value="0">全部</option>
                    @foreach ($currency_plates as $key => $plate)
                        <option value="{{$plate->id}}">{{$plate->name}}</option>
                    @endforeach
                </select>
            </div>
        </div>
    </div>
</div>
<table id="data_table" lay-filter="data_table"></table>
@endsection
@section('scripts')
<script type="text/html" id="is_display">
    <input type="checkbox" name="is_display" value="@{{d.id}}" lay-skin="switch" lay-text="是|否" lay-filter="is_display" disabled @{{ d.is_display == 1 ? 'checked' : '' }}>
</script>
<script type="text/html" id="open_transaction">
    <input type="checkbox" name="open_transaction" value="@{{d.id}}" lay-skin="switch" lay-text="开启|关闭" lay-filter="open_transaction" disabled @{{ d.open_transaction == 1 ? 'checked' : '' }}>
</script>
<script type="text/html" id="open_lever">
    <input type="checkbox" name="open_lever" value="@{{d.id}}" lay-skin="switch" lay-text="开启|关闭" lay-filter="open_lever" disabled @{{ d.open_lever == 1 ? 'checked' : '' }}>
</script>
<script type="text/html" id="open_micro">
    <input type="checkbox" name="open_micro" value="@{{d.id}}" lay-skin="switch" lay-text="开启|关闭" lay-filter="open_micro" disabled @{{ d.open_lever == 1 ? 'checked' : '' }}>
</script>
<script>
    var legal_id = {{ Request::route('legal_id') }}
    layui.use(['table', 'layer', 'form'], function() {
        var table = layui.table
            ,layer = layui.layer
            ,form = layui.form
            ,$ = layui.$
        var data_table = table.render({
            elem: '#data_table'
            ,url: '/admin/currency/match_list/' + legal_id
            ,height: 'full-100'
            ,toolbar: 'default'
            ,page: true
            ,cols: [[
                {type: 'radio'}
                ,{field: 'id', title: 'id', width: 70}
                ,{field: 'plate_name', title: '版块', width: 120}
                ,{field: 'legal_name', title: '法币', width: 80, hide: true}
                ,{field: 'currency_name', title: '交易币', width: 80}
                ,{field: 'is_display', title: '显示', width: 90, templet: '#is_display'}
                ,{field: 'open_transaction', title: '币币交易', width: 100, templet: '#open_transaction'}
                ,{field: 'open_lever', title: '合约交易', width: 100, templet: '#open_lever'}
                ,{field: 'open_micro', title: '秒合约交易', width: 100, templet: '#open_micro'}
                ,{field: 'market_from_name', title: '行情来自', width: 110}
                ,{field: 'create_time', title: '创建时间', width: 180}
            ]]
        });
        form.on('select(plate_id)', function(data) {
            data_table.reload({
                where: {plate_id: data.value}
            })
        });
        table.on('toolbar(data_table)', function (obj) {
            var id = 0
                ,selected = table.checkStatus('data_table')
            switch (obj.event) {
                case 'add':
                    layer.open({
                        title: '添加交易对'
                        ,type: 2
                        ,content: '/admin/currency/match_add/' + legal_id
                        ,area: ['600px', '380px']
                    });
                    break;
                case 'update':
                    if (selected.data.length != 1) {
                        layer.msg('只能编辑一个交易对');
                        return false;
                    }
                    id = selected.data[0].id
                    layer.open({
                        title: '编辑交易对'
                        ,type: 2
                        ,content: '/admin/currency/match_edit/' + id
                        ,area: ['600px', '380px']
                    });
                    break;
                case 'delete':
                    if (selected.data.length != 1) {
                        layer.msg('选择一个交易对才能删除');
                        return false;
                    }
                    id = selected.data[0].id
                    layer.confirm('真的确定要删除吗?', function (index) {
                        $.ajax({
                            url: '/admin/currency/match_del/' + id
                            ,type: 'GET'
                            ,success: function (res) {
                                layer.msg(res.message, {
                                    time: 2000
                                    ,end: function () {
                                        if (res.type == 'ok') {
                                            data_table.reload();
                                        }
                                    }
                                });
                            }
                            ,error: function (res) {

                            }
                        });
                    });
                    break;
                default:
                    break;
            }
        });
    });
</script>
@endsection